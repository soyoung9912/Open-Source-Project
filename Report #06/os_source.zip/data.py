import csv
import random

import numpy
from keras import Sequential
from keras.layers import Dense
from keras.utils import np_utils


csv_file = './data_all.csv'
# This should be consisted
# numpy.random.seed(5)

# Params
# hyper-parameter
epoch = 150
batch_size = 100

# Load data
total_dataset = []
file = open(csv_file, 'r', encoding='utf-8-sig')
csv_reader = csv.reader(file)
temp_list = []
for line in csv_reader:
    if line[0] == '':
        # print(temp_list[0][2], temp_list[-1][2])
        temp_max = []
        for i in range(3):
            temp_max.append(abs(temp_list[0][i] + temp_list[-1][i]))

        max_idx = temp_max.index(max(temp_max))
        data_lableing_boundary = abs((temp_list[0][max_idx] + temp_list[-1][max_idx])) * 0.65  # last float type value is boundary params
        for temp_data in temp_list:
            if abs(temp_data[max_idx]) > data_lableing_boundary:
                temp_data.append(0)  # 0 represents sitting
            else:
                temp_data.append(1)  # 1 represents standing

            total_dataset.append(temp_data)
        temp_list = []
    else:
        line = [float(item) for item in line]
        temp_list.append(line)

random.shuffle(total_dataset)
total_dataset = numpy.array(total_dataset)
# for data in total_dataset:
#     print(data)

# It represent training and testing dataset percentage n : (100-n)
dataset_division_percentage = 70
# Dataset Count
total_dataset_count = len(total_dataset)
training_dataset_count = int(total_dataset_count * dataset_division_percentage * 0.01)
test_dataset_count = total_dataset_count - training_dataset_count

train_x = total_dataset[0:training_dataset_count, 0:3]
train_y = total_dataset[0:training_dataset_count, 3]
# train_x = train_x / float(max_idx_value)  # normalization
# train_x = numpy.reshape(train_x, (training_dataset_count, train_dataset.shape[1] - 1, 1))
train_y = np_utils.to_categorical(train_y)

test_x = total_dataset[training_dataset_count:-1, 0:3]
test_y = total_dataset[training_dataset_count:-1, 3]
# test_x = test_x / float(max_idx_value)  # normalization
# test_x = numpy.reshape(test_x, (test_dataset_count, test_dataset.shape[1] - 1, 1))
test_y = np_utils.to_categorical(test_y)

model = Sequential()
model.add(Dense(128, input_dim=3, activation='sigmoid'))
model.add(Dense(128, activation='sigmoid'))
model.add(Dense(2, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])

print(model.summary())
# Train

model.fit(train_x, train_y, epochs=epoch, batch_size=batch_size, verbose=2, shuffle=False)  # 50 is X.shape[0]
# model.reset_states()

# Validation
scores = model.evaluate(test_x, test_y, batch_size=batch_size)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))

# Test
# print(numpy.argmax(model.predict(train_x, 189)))
i = 0
cnt = 0
# test_x = numpy.reshape(test_x, (test_dataset_count, sequence_size, 1))
for output in model.predict(test_x, batch_size):
    # print(str(numpy.argmax(output)) + " / " + str(numpy.argmax(test_y[i])))
    if numpy.argmax(test_y[i]) == numpy.argmax(output):
        # print(i)
        cnt += 1
    i += 1

# Results
print(str(cnt) + '/' + str(i) + ' :: ' + str(round(cnt / i, 6) * 100) + "%")